const SignUpButton = document.getElementById("signup-button");

SignUpButton.addEventListener("click", showSignUpForm);

function showSignUpForm(){
    window.location.href="homepage.html";
}
